<?php
error_reporting(-1);
$year = 1900;
echo '<select>';
while ($year <=2019){
    echo "<option value ='$year'>$year<\option>";
    $year++;
}
'<\select>';
?>














